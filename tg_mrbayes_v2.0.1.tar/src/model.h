int AreDoublesEqual (MrBFlt x, MrBFlt y, MrBFlt tol);
int CheckModel (void);
int DoLink (void);
int DoLinkParm (char *parmName, char *tkn);
int DoLset (void);
int DoLsetParm (char *parmName, char *tkn);
int DoPrset (void);
int DoPrsetParm (char *parmName, char *tkn);
int DoReport (void);
int DoReportParm (char *parmName, char *tkn);
int DoShowModel (void);
int DoUnlink (void);
int InitializeLinks (void);
int Link (void);
int NumStates (int part);
int SetUpModel (void);
int Unlink (void);

